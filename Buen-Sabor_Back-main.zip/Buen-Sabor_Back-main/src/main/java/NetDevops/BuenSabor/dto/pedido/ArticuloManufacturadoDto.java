package NetDevops.BuenSabor.dto.pedido;

import NetDevops.BuenSabor.dto.BaseDto;
import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
public class ArticuloManufacturadoDto extends BaseDto {

    private String denominacion;

}
