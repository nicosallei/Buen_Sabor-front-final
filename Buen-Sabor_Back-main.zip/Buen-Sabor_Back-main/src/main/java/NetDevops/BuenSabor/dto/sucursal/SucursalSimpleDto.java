package NetDevops.BuenSabor.dto.sucursal;

import NetDevops.BuenSabor.dto.BaseDto;
import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
public class SucursalSimpleDto extends BaseDto {
    private String nombre;
}
