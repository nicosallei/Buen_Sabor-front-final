package NetDevops.BuenSabor.service;

public interface IImagenArticuloService {
}
