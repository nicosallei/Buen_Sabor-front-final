package NetDevops.BuenSabor.service.impl;

import NetDevops.BuenSabor.service.IArticuloManufacturadoDetalleService;
import org.springframework.stereotype.Service;

@Service
public class ArticuloManufacturadoDetalleService implements IArticuloManufacturadoDetalleService {

}
