package NetDevops.BuenSabor.service;

public interface IArticuloManufacturadoDetalleService {


}
