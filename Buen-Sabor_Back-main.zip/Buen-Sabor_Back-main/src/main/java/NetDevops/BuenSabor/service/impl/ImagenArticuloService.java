package NetDevops.BuenSabor.service.impl;

import NetDevops.BuenSabor.service.IImagenArticuloService;
import org.springframework.stereotype.Service;

@Service
public class ImagenArticuloService implements IImagenArticuloService {

}
