package NetDevops.BuenSabor.enums;

public enum FormaPago {
    EFECTIVO,
    MERCADOPAGO
}
