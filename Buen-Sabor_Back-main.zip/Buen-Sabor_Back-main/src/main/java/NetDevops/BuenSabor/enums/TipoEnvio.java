package NetDevops.BuenSabor.enums;

public enum TipoEnvio {
    DELIVERY,
    RETIRO_LOCAL
}
