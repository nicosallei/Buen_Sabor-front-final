package NetDevops.BuenSabor.enums;

public enum TipoPromocion {
    HAPPY_HOUR,
    PROMOCION
}
