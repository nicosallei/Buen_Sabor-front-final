package NetDevops.BuenSabor.enums;

import org.springframework.security.access.prepost.PreAuthorize;

public enum Rol {
    ADMINISTRADOR,
    CLIENTE,
    EMPLEADO_COCINA,
    EMPLEADO_REPARTIDOR,
    EMPLEADO_CAJA
}
