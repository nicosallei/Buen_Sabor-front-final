package NetDevops.BuenSabor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BuenSaborApplication {

	public static void main(String[] args) {

		SpringApplication.run(BuenSaborApplication.class, args);
		System.out.println("Arranco el programa Buen Sabor");
	}



}
