package NetDevops.BuenSabor.entities.mercadoPago;

import lombok.Data;

@Data
public class PreferenceMP {
    private String id;
    private int statusCode;
}
